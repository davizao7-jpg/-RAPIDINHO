-- ============================================================
-- RAPIDINHO — schema do banco de dados (Supabase / Postgres)
-- ============================================================
-- Como usar: entre no seu projeto Supabase → SQL Editor → cole
-- este arquivo inteiro → Run. Isso cria todas as tabelas, as
-- regras de segurança (RLS) e as funções automáticas.
-- ============================================================

-- Extensão necessária para gerar IDs únicos
create extension if not exists "uuid-ossp";

-- ------------------------------------------------------------
-- PERFIS (dados públicos de cada usuário, além do login)
-- ------------------------------------------------------------
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  avatar_url text,
  bio text,
  criado_em timestamptz default now(),

  -- contadores (atualizados por trigger, não editar na mão)
  seguidores_count int default 0,
  seguindo_count int default 0,
  likes_recebidos_count int default 0,

  -- gamificação do quiz
  quiz_nivel int default 1,
  quiz_xp int default 0,
  quiz_acertos_total int default 0
);

alter table profiles enable row level security;

create policy "Perfis são públicos para leitura"
  on profiles for select using (true);

create policy "Usuário só edita o próprio perfil"
  on profiles for update using (auth.uid() = id);

create policy "Usuário cria o próprio perfil"
  on profiles for insert with check (auth.uid() = id);


-- ------------------------------------------------------------
-- POSTS (links de vídeo colados pelo usuário)
-- ------------------------------------------------------------
create table posts (
  id uuid primary key default uuid_generate_v4(),
  autor_id uuid references profiles(id) on delete cascade not null,
  url_original text not null,       -- link colado pelo usuário (TikTok/YouTube/etc)
  plataforma text not null,          -- 'tiktok' | 'youtube' | 'instagram'
  video_id text not null,            -- id extraído da url, usado pro embed
  legenda text,                      -- texto opcional que o usuário escreve junto
  criado_em timestamptz default now(),
  likes_count int default 0,
  comentarios_count int default 0,
  views_count int default 0
);

alter table posts enable row level security;

create policy "Posts são públicos para leitura"
  on posts for select using (true);

create policy "Usuário logado pode postar"
  on posts for insert with check (auth.uid() = autor_id);

create policy "Autor pode apagar o próprio post"
  on posts for delete using (auth.uid() = autor_id);


-- ------------------------------------------------------------
-- VIEWS (histórico de quem já viu qual vídeo — pro feed não repetir)
-- ------------------------------------------------------------
create table post_views (
  id bigint generated always as identity primary key,
  post_id uuid references posts(id) on delete cascade not null,
  usuario_id uuid references profiles(id) on delete cascade not null,
  visto_em timestamptz default now(),
  unique (post_id, usuario_id)  -- 1 view só conta 1 vez por usuário
);

alter table post_views enable row level security;

create policy "Usuário vê o próprio histórico"
  on post_views for select using (auth.uid() = usuario_id);

create policy "Usuário registra a própria view"
  on post_views for insert with check (auth.uid() = usuario_id);


-- ------------------------------------------------------------
-- LIKES
-- ------------------------------------------------------------
create table likes (
  id bigint generated always as identity primary key,
  post_id uuid references posts(id) on delete cascade not null,
  usuario_id uuid references profiles(id) on delete cascade not null,
  criado_em timestamptz default now(),
  unique (post_id, usuario_id)
);

alter table likes enable row level security;

create policy "Likes são públicos para leitura"
  on likes for select using (true);

create policy "Usuário logado pode curtir"
  on likes for insert with check (auth.uid() = usuario_id);

create policy "Usuário pode descurtir o próprio like"
  on likes for delete using (auth.uid() = usuario_id);


-- ------------------------------------------------------------
-- COMENTÁRIOS
-- ------------------------------------------------------------
create table comentarios (
  id uuid primary key default uuid_generate_v4(),
  post_id uuid references posts(id) on delete cascade not null,
  autor_id uuid references profiles(id) on delete cascade not null,
  texto text not null,
  criado_em timestamptz default now()
);

alter table comentarios enable row level security;

create policy "Comentários são públicos para leitura"
  on comentarios for select using (true);

create policy "Usuário logado pode comentar"
  on comentarios for insert with check (auth.uid() = autor_id);

create policy "Autor pode apagar o próprio comentário"
  on comentarios for delete using (auth.uid() = autor_id);


-- ------------------------------------------------------------
-- SEGUIDORES
-- ------------------------------------------------------------
create table seguidores (
  id bigint generated always as identity primary key,
  seguidor_id uuid references profiles(id) on delete cascade not null,
  seguindo_id uuid references profiles(id) on delete cascade not null,
  criado_em timestamptz default now(),
  unique (seguidor_id, seguindo_id),
  check (seguidor_id <> seguindo_id)  -- não pode seguir a si mesmo
);

alter table seguidores enable row level security;

create policy "Relações de seguir são públicas para leitura"
  on seguidores for select using (true);

create policy "Usuário logado pode seguir"
  on seguidores for insert with check (auth.uid() = seguidor_id);

create policy "Usuário pode deixar de seguir"
  on seguidores for delete using (auth.uid() = seguidor_id);


-- ------------------------------------------------------------
-- QUIZZES E PERGUNTAS (conteúdo fixo, cadastrado por você)
-- ------------------------------------------------------------
create table quizzes (
  id uuid primary key default uuid_generate_v4(),
  titulo text not null,
  categoria text not null,   -- ex: 'qi', 'cultura geral', 'personalidade'
  ordem int default 0
);

create table quiz_perguntas (
  id uuid primary key default uuid_generate_v4(),
  quiz_id uuid references quizzes(id) on delete cascade not null,
  pergunta text not null,
  opcoes jsonb not null,       -- ex: ["Opção A", "Opção B", "Opção C", "Opção D"]
  resposta_correta int not null, -- índice (0-3) da opção certa
  ordem int default 0
);

alter table quizzes enable row level security;
alter table quiz_perguntas enable row level security;

create policy "Quizzes são públicos para leitura"
  on quizzes for select using (true);

create policy "Perguntas são públicas para leitura"
  on quiz_perguntas for select using (true);


-- ------------------------------------------------------------
-- RESULTADOS DE QUIZ (histórico de tentativas, alimenta XP/ranking)
-- ------------------------------------------------------------
create table quiz_resultados (
  id bigint generated always as identity primary key,
  usuario_id uuid references profiles(id) on delete cascade not null,
  quiz_id uuid references quizzes(id) on delete cascade not null,
  acertos int not null,
  total_perguntas int not null,
  xp_ganho int not null,
  concluido_em timestamptz default now()
);

alter table quiz_resultados enable row level security;

create policy "Usuário vê o próprio histórico de quiz"
  on quiz_resultados for select using (auth.uid() = usuario_id);

create policy "Usuário registra o próprio resultado"
  on quiz_resultados for insert with check (auth.uid() = usuario_id);


-- ============================================================
-- FUNÇÕES AUTOMÁTICAS (triggers) — mantêm os contadores certos
-- sem precisar calcular isso no JavaScript toda hora
-- ============================================================

-- Contador de likes no post
create or replace function atualizar_likes_count() returns trigger as $$
begin
  if (tg_op = 'INSERT') then
    update posts set likes_count = likes_count + 1 where id = new.post_id;
    update profiles set likes_recebidos_count = likes_recebidos_count + 1
      where id = (select autor_id from posts where id = new.post_id);
  elsif (tg_op = 'DELETE') then
    update posts set likes_count = likes_count - 1 where id = old.post_id;
    update profiles set likes_recebidos_count = likes_recebidos_count - 1
      where id = (select autor_id from posts where id = old.post_id);
  end if;
  return null;
end;
$$ language plpgsql security definer;

create trigger trg_likes_count
  after insert or delete on likes
  for each row execute function atualizar_likes_count();


-- Contador de comentários no post
create or replace function atualizar_comentarios_count() returns trigger as $$
begin
  update posts set comentarios_count = comentarios_count + 1 where id = new.post_id;
  return new;
end;
$$ language plpgsql security definer;

create trigger trg_comentarios_count
  after insert on comentarios
  for each row execute function atualizar_comentarios_count();


-- Contador de views no post
create or replace function atualizar_views_count() returns trigger as $$
begin
  update posts set views_count = views_count + 1 where id = new.post_id;
  return new;
end;
$$ language plpgsql security definer;

create trigger trg_views_count
  after insert on post_views
  for each row execute function atualizar_views_count();


-- Contadores de seguidor/seguindo
create or replace function atualizar_seguidores_count() returns trigger as $$
begin
  if (tg_op = 'INSERT') then
    update profiles set seguidores_count = seguidores_count + 1 where id = new.seguindo_id;
    update profiles set seguindo_count = seguindo_count + 1 where id = new.seguidor_id;
  elsif (tg_op = 'DELETE') then
    update profiles set seguidores_count = seguidores_count - 1 where id = old.seguindo_id;
    update profiles set seguindo_count = seguindo_count - 1 where id = old.seguidor_id;
  end if;
  return null;
end;
$$ language plpgsql security definer;

create trigger trg_seguidores_count
  after insert or delete on seguidores
  for each row execute function atualizar_seguidores_count();


-- XP e nível após concluir quiz (1 XP por acerto, sobe de nível a cada 20 XP)
create or replace function aplicar_xp_quiz() returns trigger as $$
begin
  update profiles
  set quiz_xp = quiz_xp + new.xp_ganho,
      quiz_acertos_total = quiz_acertos_total + new.acertos,
      quiz_nivel = 1 + floor((quiz_xp + new.xp_ganho) / 20)
  where id = new.usuario_id;
  return new;
end;
$$ language plpgsql security definer;

create trigger trg_aplicar_xp
  after insert on quiz_resultados
  for each row execute function aplicar_xp_quiz();


-- Cria o perfil automaticamente quando alguém se cadastra
create or replace function criar_perfil_automatico() returns trigger as $$
begin
  insert into public.profiles (id, username)
  values (new.id, 'usuario_' || substr(new.id::text, 1, 8));
  return new;
end;
$$ language plpgsql security definer;

create trigger trg_criar_perfil
  after insert on auth.users
  for each row execute function criar_perfil_automatico();


-- ============================================================
-- FIM DO SCHEMA
-- Depois de rodar isso, vá na tabela "quizzes" e "quiz_perguntas"
-- pelo painel do Supabase e cadastre as perguntas manualmente
-- (ou me peça uma lista pronta pra colar).
-- ============================================================
