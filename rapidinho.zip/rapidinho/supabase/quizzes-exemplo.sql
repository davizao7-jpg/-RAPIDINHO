-- ============================================================
-- QUIZZES DE EXEMPLO — rode isso depois do schema.sql pra já
-- ter conteúdo no app assim que publicar. São 6 quizzes com
-- 15 perguntas cada (o QI tem 15, dá pra editar pra 20 depois
-- direto no painel do Supabase, tabela quiz_perguntas).
-- ============================================================

-- ---------- 1. QI RÁPIDO ----------
insert into quizzes (id, titulo, categoria, ordem) values
  ('11111111-0000-0000-0000-000000000001', 'QI Rápido', 'qi', 1);

insert into quiz_perguntas (quiz_id, pergunta, opcoes, resposta_correta, ordem) values
  ('11111111-0000-0000-0000-000000000001', 'Qual número continua a sequência: 2, 4, 8, 16, ?', '["20", "24", "32", "18"]', 2, 1),
  ('11111111-0000-0000-0000-000000000001', 'Se todos os Bips são Baps, e todos os Baps são Bups, então todos os Bips são:', '["Bups", "Baps apenas", "Nem sempre Bups", "Nenhuma das opções"]', 0, 2),
  ('11111111-0000-0000-0000-000000000001', 'Complete: PRETO está para BRANCO assim como QUENTE está para:', '["Morno", "Frio", "Fogo", "Verão"]', 1, 3),
  ('11111111-0000-0000-0000-000000000001', 'Qual desses não pertence ao grupo?', '["Maçã", "Banana", "Cenoura", "Uva"]', 2, 4),
  ('11111111-0000-0000-0000-000000000001', 'Continue a sequência: 1, 1, 2, 3, 5, 8, ?', '["11", "13", "12", "10"]', 1, 5),
  ('11111111-0000-0000-0000-000000000001', 'Se um relógio marca 3:15, qual o ângulo aproximado entre os ponteiros?', '["0°", "7,5°", "90°", "180°"]', 1, 6),
  ('11111111-0000-0000-0000-000000000001', 'Qual figura completa o padrão: círculo, quadrado, círculo, quadrado, ?', '["Círculo", "Triângulo", "Quadrado", "Losango"]', 0, 7),
  ('11111111-0000-0000-0000-000000000001', 'Ana é mais velha que Bia. Bia é mais velha que Carla. Quem é a mais nova?', '["Ana", "Bia", "Carla", "Não dá pra saber"]', 2, 8),
  ('11111111-0000-0000-0000-000000000001', 'Qual número não pertence: 3, 5, 7, 9, 11, 14?', '["9", "11", "14", "5"]', 2, 9),
  ('11111111-0000-0000-0000-000000000001', 'Complete: LIVRO está para LER assim como GARFO está para:', '["Cozinhar", "Comer", "Cortar", "Lavar"]', 1, 10),
  ('11111111-0000-0000-0000-000000000001', 'Qual a próxima letra: A, C, E, G, ?', '["H", "I", "J", "F"]', 1, 11),
  ('11111111-0000-0000-0000-000000000001', 'Se 5 máquinas fazem 5 produtos em 5 minutos, quanto tempo 100 máquinas levam pra fazer 100 produtos?', '["100 minutos", "20 minutos", "5 minutos", "1 minuto"]', 2, 12),
  ('11111111-0000-0000-0000-000000000001', 'Qual desses é um antônimo de "efêmero"?', '["Passageiro", "Duradouro", "Rápido", "Instável"]', 1, 13),
  ('11111111-0000-0000-0000-000000000001', 'Continue: 100, 90, 81, 73, ?', '["66", "64", "70", "68"]', 0, 14),
  ('11111111-0000-0000-0000-000000000001', 'Se você embaralhar as letras de "ROMA", qual destas NÃO pode ser formada?', '["AMOR", "RAMO", "MORA", "MOTA"]', 3, 15);

-- ---------- 2. VOCÊ SABIA? (curiosidades) ----------
insert into quizzes (id, titulo, categoria, ordem) values
  ('22222222-0000-0000-0000-000000000002', 'Você Sabia?', 'curiosidades', 2);

insert into quiz_perguntas (quiz_id, pergunta, opcoes, resposta_correta, ordem) values
  ('22222222-0000-0000-0000-000000000002', 'Qual é o maior país do mundo em área?', '["China", "Estados Unidos", "Rússia", "Brasil"]', 2, 1),
  ('22222222-0000-0000-0000-000000000002', 'Quantos ossos tem o corpo humano adulto?', '["186", "206", "226", "246"]', 1, 2),
  ('22222222-0000-0000-0000-000000000002', 'Qual animal terrestre é o mais rápido do mundo?', '["Leão", "Guepardo", "Cavalo", "Avestruz"]', 1, 3),
  ('22222222-0000-0000-0000-000000000002', 'Em que ano o homem pisou na Lua pela primeira vez?', '["1965", "1969", "1972", "1959"]', 1, 4),
  ('22222222-0000-0000-0000-000000000002', 'Qual é o maior órgão do corpo humano?', '["Fígado", "Coração", "Pele", "Pulmão"]', 2, 5),
  ('22222222-0000-0000-0000-000000000002', 'Quantos corações tem um polvo?', '["1", "2", "3", "4"]', 2, 6),
  ('22222222-0000-0000-0000-000000000002', 'Qual é o único mamífero capaz de voar de verdade?', '["Esquilo-voador", "Morcego", "Falcão", "Nenhum"]', 1, 7),
  ('22222222-0000-0000-0000-000000000002', 'Qual desses países fica em três continentes ao mesmo tempo?', '["Egito", "Turquia", "Rússia", "Todos os anteriores"]', 3, 8),
  ('22222222-0000-0000-0000-000000000002', 'Qual é o metal líquido à temperatura ambiente?', '["Ferro", "Mercúrio", "Chumbo", "Alumínio"]', 1, 9),
  ('22222222-0000-0000-0000-000000000002', 'Quanto tempo a luz do Sol demora pra chegar na Terra?', '["8 segundos", "8 minutos", "8 horas", "instantâneo"]', 1, 10),
  ('22222222-0000-0000-0000-000000000002', 'Qual desses é o menor país do mundo?', '["Mônaco", "Vaticano", "San Marino", "Liechtenstein"]', 1, 11),
  ('22222222-0000-0000-0000-000000000002', 'Quantos corações não tem uma minhoca? (pergunta pegadinha)', '["Ela tem 5", "Ela não tem coração", "Ela tem 1", "Ela tem 10"]', 0, 12),
  ('22222222-0000-0000-0000-000000000002', 'Qual é o oceano mais profundo?', '["Atlântico", "Índico", "Pacífico", "Ártico"]', 2, 13),
  ('22222222-0000-0000-0000-000000000002', 'Em que continente fica o deserto do Saara?', '["Ásia", "África", "Austrália", "América do Sul"]', 1, 14),
  ('22222222-0000-0000-0000-000000000002', 'Qual desses elementos é o mais abundante no universo?', '["Oxigênio", "Carbono", "Hidrogênio", "Hélio"]', 2, 15);

-- ---------- 3. CULTURA POP ----------
insert into quizzes (id, titulo, categoria, ordem) values
  ('33333333-0000-0000-0000-000000000003', 'Cultura Pop', 'entretenimento', 3);

insert into quiz_perguntas (quiz_id, pergunta, opcoes, resposta_correta, ordem) values
  ('33333333-0000-0000-0000-000000000003', 'Qual desses NÃO é um streaming de vídeo?', '["Netflix", "Spotify", "Prime Video", "Disney+"]', 1, 1),
  ('33333333-0000-0000-0000-000000000003', 'Qual rede social é conhecida pelo formato de vídeos curtos verticais?', '["LinkedIn", "TikTok", "Pinterest", "Reddit"]', 1, 2),
  ('33333333-0000-0000-0000-000000000003', 'Em qual país nasceu o k-pop?', '["Japão", "China", "Coreia do Sul", "Tailândia"]', 2, 3),
  ('33333333-0000-0000-0000-000000000003', 'Qual desses é um gênero musical brasileiro?', '["Reggaeton", "Funk carioca", "K-pop", "J-pop"]', 1, 4),
  ('33333333-0000-0000-0000-000000000003', 'Quantos jogadores tem um time de futebol em campo?', '["9", "10", "11", "12"]', 2, 5),
  ('33333333-0000-0000-0000-000000000003', 'Qual desses é um console de videogame?', '["PlayStation", "iCloud", "Chromecast", "AirPods"]', 0, 6),
  ('33333333-0000-0000-0000-000000000003', 'Qual super-herói é conhecido como o "Homem de Ferro"?', '["Steve Rogers", "Tony Stark", "Bruce Wayne", "Peter Parker"]', 1, 7),
  ('33333333-0000-0000-0000-000000000003', 'Em que tipo de conteúdo o YouTube Shorts se especializa?', '["Vídeos longos", "Vídeos curtos verticais", "Podcasts", "Lives apenas"]', 1, 8),
  ('33333333-0000-0000-0000-000000000003', 'Qual desses aplicativos é usado pra edição de fotos?', '["Canva", "Excel", "Zoom", "Slack"]', 0, 9),
  ('33333333-0000-0000-0000-000000000003', 'Qual é a maior plataforma de streaming de música do mundo?', '["Deezer", "Spotify", "Tidal", "SoundCloud"]', 1, 10),
  ('33333333-0000-0000-0000-000000000003', 'Em qual desses esportes se usa uma raquete?', '["Vôlei", "Tênis", "Futebol", "Basquete"]', 1, 11),
  ('33333333-0000-0000-0000-000000000003', 'Qual país sediou a Copa do Mundo de 2022?', '["Rússia", "Brasil", "Catar", "Japão"]', 2, 12),
  ('33333333-0000-0000-0000-000000000003', 'O que significa a sigla "IA" na tecnologia?', '["Internet Avançada", "Inteligência Artificial", "Interface de Áudio", "Informação Automática"]', 1, 13),
  ('33333333-0000-0000-0000-000000000003', 'Qual desses é um gênero de filme?', '["Podcast", "Comédia", "Playlist", "Feed"]', 1, 14),
  ('33333333-0000-0000-0000-000000000003', 'Qual rede social pertence à mesma empresa do Instagram?', '["TikTok", "WhatsApp", "Twitter/X", "Snapchat"]', 1, 15);

-- ---------- 4. TESTE DE PERSONALIDADE ----------
insert into quizzes (id, titulo, categoria, ordem) values
  ('44444444-0000-0000-0000-000000000004', 'Qual seu perfil?', 'personalidade', 4);

insert into quiz_perguntas (quiz_id, pergunta, opcoes, resposta_correta, ordem) values
  ('44444444-0000-0000-0000-000000000004', 'Num sábado livre, você prefere:', '["Ficar em casa", "Sair com amigos", "Fazer algo produtivo", "Depende do humor"]', 3, 1),
  ('44444444-0000-0000-0000-000000000004', 'Quando algo dá errado, você:', '["Fica calmo e resolve", "Fica ansioso", "Culpa a situação", "Ignora e segue"]', 0, 2),
  ('44444444-0000-0000-0000-000000000004', 'Seu tipo de conteúdo favorito:', '["Comédia", "Motivacional", "Curiosidades", "Notícias"]', 0, 3),
  ('44444444-0000-0000-0000-000000000004', 'Como você toma decisões?', '["Rápido, no instinto", "Pensa bastante antes", "Pede opinião de outros", "Depende do dia"]', 1, 4),
  ('44444444-0000-0000-0000-000000000004', 'Em um grupo, você costuma ser:', '["O líder", "O apoiador", "O observador", "O engraçado"]', 3, 5),
  ('44444444-0000-0000-0000-000000000004', 'Seu maior objetivo agora:', '["Ganhar dinheiro", "Ser feliz", "Aprender coisas novas", "Ter mais tempo livre"]', 0, 6),
  ('44444444-0000-0000-0000-000000000004', 'Como você lida com crítica?', '["Leva a sério", "Ignora", "Fica chateado, mas pensa depois", "Discorda na hora"]', 2, 7),
  ('44444444-0000-0000-0000-000000000004', 'Seu ritmo de vida:', '["Corrido", "Tranquilo", "Equilibrado", "Imprevisível"]', 3, 8),
  ('44444444-0000-0000-0000-000000000004', 'O que mais te motiva?', '["Reconhecimento", "Dinheiro", "Superação pessoal", "Ajudar os outros"]', 2, 9),
  ('44444444-0000-0000-0000-000000000004', 'Você se descreve como:', '["Extrovertido", "Introvertido", "Um pouco dos dois", "Depende da situação"]', 3, 10),
  ('44444444-0000-0000-0000-000000000004', 'Diante de um problema difícil, você:', '["Enfrenta de cara", "Planeja antes de agir", "Pede ajuda", "Adia até não dar mais"]', 1, 11),
  ('44444444-0000-0000-0000-000000000004', 'O que você mais valoriza numa amizade?', '["Lealdade", "Diversão", "Sinceridade", "Apoio"]', 2, 12),
  ('44444444-0000-0000-0000-000000000004', 'Como você reage a mudanças repentinas?', '["Se adapta rápido", "Fica desconfortável", "Acha empolgante", "Prefere evitar"]', 0, 13),
  ('44444444-0000-0000-0000-000000000004', 'Seu jeito de aprender algo novo:', '["Praticando direto", "Assistindo vídeo", "Lendo sobre", "Perguntando pra alguém"]', 0, 14),
  ('44444444-0000-0000-0000-000000000004', 'No fim do dia, você se sente mais:', '["Realizado", "Cansado", "Tranquilo", "Ansioso pro amanhã"]', 0, 15);

-- ---------- 5. VOCÊ SOBREVIVERIA? ----------
insert into quizzes (id, titulo, categoria, ordem) values
  ('55555555-0000-0000-0000-000000000005', 'Você Sobreviveria?', 'desafio', 5);

insert into quiz_perguntas (quiz_id, pergunta, opcoes, resposta_correta, ordem) values
  ('55555555-0000-0000-0000-000000000005', 'Perdido na mata, a prioridade número 1 é:', '["Comida", "Água", "Abrigo", "Fazer fogo"]', 1, 1),
  ('55555555-0000-0000-0000-000000000005', 'Quantos dias em média o corpo aguenta sem água?', '["1 dia", "3 dias", "10 dias", "30 dias"]', 1, 2),
  ('55555555-0000-0000-0000-000000000005', 'Se picado por uma cobra, você deve:', '["Cortar o local e sugar", "Correr o mais rápido possível", "Manter calmo e imobilizar o membro", "Amarrar bem apertado acima da picada"]', 2, 3),
  ('55555555-0000-0000-0000-000000000005', 'Pra saber onde é o norte sem bússola, você pode usar:', '["A posição do sol", "O cheiro do vento", "A cor do céu", "Não tem como saber"]', 0, 4),
  ('55555555-0000-0000-0000-000000000005', 'Num incêndio em casa, o certo é:', '["Correr em pé", "Rastejar perto do chão", "Abrir todas as janelas", "Esperar a fumaça baixar"]', 1, 5),
  ('55555555-0000-0000-0000-000000000005', 'Água de rio parada é segura pra beber sem tratar?', '["Sim, sempre", "Não, pode ter contaminação", "Só se estiver cristalina", "Só em época de seca"]', 1, 6),
  ('55555555-0000-0000-0000-000000000005', 'Se um carro cai n''água, a primeira coisa a fazer é:', '["Esperar afundar", "Tentar abrir a porta imediatamente", "Ligar pro seguro", "Quebrar o para-brisa"]', 1, 7),
  ('55555555-0000-0000-0000-000000000005', 'Pra fazer fogo sem isqueiro, uma opção é:', '["Atrito entre madeiras", "Bater duas pedras quaisquer", "Esfregar as mãos", "Gritar bem alto"]', 0, 8),
  ('55555555-0000-0000-0000-000000000005', 'Se avistar um urso, o ideal é:', '["Correr", "Fazer barulho e recuar devagar", "Fazer contato visual direto e gritar", "Fingir de morto sempre"]', 1, 9),
  ('55555555-0000-0000-0000-000000000005', 'Quanto tempo em média se sobrevive sem comida?', '["3 dias", "1 semana", "3 semanas", "2 meses"]', 2, 10),
  ('55555555-0000-0000-0000-000000000005', 'Se está perdido, o mais indicado geralmente é:', '["Continuar andando sem parar", "Ficar num só lugar visível e sinalizar", "Andar só à noite", "Cavar um buraco"]', 1, 11),
  ('55555555-0000-0000-0000-000000000005', 'Raio caindo por perto: o mais seguro é:', '["Ficar embaixo de uma árvore alta", "Se abaixar num local baixo, longe de objetos altos", "Correr em campo aberto", "Segurar em algo de metal"]', 1, 12),
  ('55555555-0000-0000-0000-000000000005', 'Pra purificar água de fonte duvidosa, o método mais simples é:', '["Deixar parada 1 hora", "Ferver por alguns minutos", "Adicionar sal", "Congelar"]', 1, 13),
  ('55555555-0000-0000-0000-000000000005', 'Em alto mar sem resgate à vista, prioridade é:', '["Nadar até a costa mais próxima", "Conservar energia e sinalizar", "Beber água do mar aos poucos", "Mergulhar procurando comida"]', 1, 14),
  ('55555555-0000-0000-0000-000000000005', 'Se ficar isolado no frio extremo, o maior risco imediato é:', '["Fome", "Hipotermia", "Desidratação", "Insolação"]', 1, 15);
